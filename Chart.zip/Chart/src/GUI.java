import javax.swing.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.*;

public class GUI extends JFrame {
    public GUI(){


        // dhmiourgia mia domis kai prosthikis ton dedomenwn
        DefaultCategoryDataset dataSet = new DefaultCategoryDataset();

        dataSet.addValue(212,"Classes", "JDK 1.0");
        dataSet.addValue(504,"Classes", "JDK 1.1");
        dataSet.addValue(1520,"Classes", "SDK 1.2");
        dataSet.addValue(1842,"Classes", "SDK 1.3");
        dataSet.addValue(2991,"Classes", "JDK 1.4");

        //ftiaxnw to diagramma me mia mono entoli
        // to deytero meros peirexei allh klasi h opoia perilamvanei methodo ergastastio h opoia epistrefei objects
        JFreeChart chart = ChartFactory.createBarChart3D("Evolution of JDK clasess", "JDK versions","Class count", dataSet, PlotOrientation.HORIZONTAL,false,true,false);

        //ftiaxnw ena chart panel o opoios periexei to diagramma
        ChartPanel panel = new ChartPanel(chart);

        //metavivazw to panel sto frame
        this.setContentPane(panel);




        this.setVisible(true);
        this.setSize(400,400);

    }
}
