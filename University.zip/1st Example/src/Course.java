public class Course {

    private String name;
    private int credits;


    public Course(String aName, int aCredits){
        name = aName;
        credits = aCredits;
    }

    public String getName() {
        return name;
    }

    public int getCredits(){
        return credits;
    }
}
