import javax.swing.*;
import java.util.ArrayList;

public class Read {



    public  static void readData(ArrayList<Student> students, ArrayList<Course> courses){

        boolean more = true;

        while (more) {

            String selection = JOptionPane.showInputDialog("1. Student  2. Graduate");
            int choice = Integer.parseInt((selection));

            String name = JOptionPane.showInputDialog("Name");
            String id = JOptionPane.showInputDialog("ID");



            String superivasorName = null;
            if (choice == 2) {
                superivasorName = JOptionPane.showInputDialog("Supervisor's name");
            }

            Student student;
            if (choice == 1){

                student = new Student(name, id);
            }

            else{
                student = new Postgraduate(name, id, superivasorName);
            }

            String  courseName = JOptionPane.showInputDialog("1. Java  2. Math");

            for (Course course: courses) {
                if (course.getName().equals(courseName))
                    student.addCourses(course);
            }

            students.add(student);

            String asnwer = JOptionPane.showInputDialog("More Students : Y/N");

            if (asnwer.equals("N")){
                more = false;
            }

            else
                more = true;

        }

    }
}
