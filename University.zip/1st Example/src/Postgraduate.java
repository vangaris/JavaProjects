public class Postgraduate extends Student {

    private String supervisor;

    public Postgraduate(String aName, String anId, String aSupervisor){
        super(aName,anId);
        supervisor = aSupervisor;
    }

    public void printInfo(){
        super.printInfo();
        System.out.println("Supervisor: " + supervisor);
    }
}
