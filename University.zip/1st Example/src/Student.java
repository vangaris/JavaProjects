import java.util.ArrayList;

public class Student {

    private String name;
    private String id;
    private ArrayList <Course> courses = new ArrayList<Course>();


    public void addCourses(Course aCourse){
        courses.add(aCourse);

    }

    public Student(String aName, String anId){
        name = aName;
        id = anId;
    }

    public void printInfo(){
        System.out.println("Name: " + name + " id: " + id);
        System.out.println("Has enrolled: ");
        for (Course c: courses){
            System.out.println( "Name: " + c.getName() + " Credits: " + c.getCredits());

        }
    }
}
