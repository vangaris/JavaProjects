import java.util.ArrayList;


public class Tameio {

	private String titlos;
	private String edra; 
	private ArrayList<Asfalismenos> asfalismenoi = new ArrayList<Asfalismenos>();
	
	public Tameio(String text1, String text2) {
		titlos = text1;
		edra = text2;
	}
	
	public String getTitlos() {
		return titlos;
	}
	
	public void add(Asfalismenos a) {
		asfalismenoi.add(a);
	}
	
	public String getName() {
		return titlos;
	}
	
	public void printAll() {
		for(Asfalismenos a: asfalismenoi) {
			System.out.println(a.getName());
			System.out.println(a.calcIncome());
		}
	}

}
