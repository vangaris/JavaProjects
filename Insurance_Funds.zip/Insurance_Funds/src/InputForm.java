import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class InputForm extends JFrame {

	private ArrayList<Tameio> tameia;
	private JPanel panel;
	private JList list;
	
	private JButton kataxwrisi;
	private JButton ektypwsi;
	
	private JTextField nameField = new JTextField("onoma");
	private JTextField AFMField = new JTextField("AFM");
	private JTextField posostoField = new JTextField("pososto");
	private JTextField incomeField = new JTextField("income");
	private JTextField childrenField = new JTextField("paidia");
	private JRadioButton misthotosRadio = new JRadioButton("misthotos");
	private JRadioButton syntaxRadio = new JRadioButton("syntax");
	
	public InputForm(ArrayList<Tameio> tameia) {
		
		this.tameia = tameia;
		
		panel = new JPanel();
		panel.add(nameField);
		panel.add(AFMField);
		panel.add(posostoField);
		panel.add(incomeField);
		panel.add(childrenField);
		panel.add(misthotosRadio);
		panel.add(syntaxRadio);
		
		DefaultListModel model = new DefaultListModel();
		for(Tameio t: tameia) {
			model.addElement(t.getTitlos());
		}
		
		list = new JList(model);
		
		kataxwrisi = new JButton("Kataxwrisi");
		ektypwsi = new JButton("Ektypwsi");
		
		panel.add(list);
		panel.add(kataxwrisi);
		panel.add(ektypwsi);
		
		this.setContentPane(panel);
	
		ButtonListener listener = new ButtonListener();
		kataxwrisi.addActionListener(listener);
		ektypwsi.addActionListener(listener);
		
		this.setSize(500, 500);
		this.setVisible(true);
		this.setTitle("Input Form");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource().equals(kataxwrisi)) {
				
				String name = nameField.getText();
				String AFM = AFMField.getText();
				String posostoText = posostoField.getText();
				double pososto = Double.parseDouble(posostoText);
				
				String selectedTameioName = (String)list.getSelectedValue();
				Tameio selectedTameio = null;
				for(Tameio t: tameia) {
					if(t.getTitlos().equals(selectedTameioName))
						selectedTameio = t;
				}
				
				if(misthotosRadio.isSelected()) {
					String incomeText = incomeField.getText();
					double income = Double.parseDouble(incomeText);
					String childrenText = childrenField.getText();
					int children = Integer.parseInt(childrenText);
					Ergazomenos erg = new Ergazomenos(name, AFM, pososto, income, children);
					selectedTameio.add(erg);
				}
				else if(syntaxRadio.isSelected()) {
					String incomeText = incomeField.getText();
					double income = Double.parseDouble(incomeText);
					
					Syntaxiouhos synt = new Syntaxiouhos(name, AFM, pososto, income);
					selectedTameio.add(synt);
				}
			}
			else if(e.getSource().equals(ektypwsi)) {
				String selectedTameioName = (String)list.getSelectedValue();
				Tameio selectedTameio = null;
				for(Tameio t: tameia) {
					if(t.getTitlos().equals(selectedTameioName))
						selectedTameio = t;
				}
				
				selectedTameio.printAll();
			}
		}
	}

}
