import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {

       Collection<String> set1 = new HashSet<String>();


       set1.add("a");
       set1.add("b");
       set1.add("c");
       set1.add("d");

       Collection<String> set2 = new HashSet<String>();

       set2.add("d");
       set2.add("e");
       set2.add("f");

       //return true if s2 is a subject of s1
        if (set1.containsAll(set2)){
            System.out.println("Set2 is a subject of s1");
        }
        else{
            System.out.println("Set2 isn't a subject of s1");
        }

        //return the union of s2 => s1
        set1.addAll(set2);

        System.out.println("union");
        for (String s: set1){

            System.out.println(s);

        }

        //return the intersection of s1 kai s2
        set1.retainAll(set2);
        System.out.println("intersection");
        for (String s: set1){

            System.out.println(s);
        }

        //transform set1 into the difference pf set1 and set 2
        //set\set2 is the set cpntaining  all elements in set1
        //but not in set 2
        System.out.println(set1);
        System.out.println(set2);
        System.out.println("difference");
        set1.removeAll(set2);
        for (String s: set1){

            System.out.println(s);
        }

    }
}
