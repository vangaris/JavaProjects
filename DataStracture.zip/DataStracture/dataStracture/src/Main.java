import java.util.HashSet;

public class Main {

    // pws na ksexorizw diplotipa logariasmos trapezas os pro to code
    public static void main(String[] args) {

        BankAccount BA1 = new BankAccount(1500,"001");
        BankAccount BA2 = new BankAccount(1500,"001");

        HashSet<BankAccount> set = new HashSet<BankAccount>();
        set.add(BA1);
        set.add(BA2);

        for(BankAccount account: set)
            System.out.println(account.getCode() + ", " + account.getBalance());

    }
}
