public class BankAccount {

    private double balance;
    private String code;

    public BankAccount(double aBalance, String aCode){
        balance = aBalance;
        code = aCode;
    }

    public double getBalance(){
        return balance;
    }

    public int hashCode(){
        return code.hashCode();
    }

    public boolean equals(Object other){
        BankAccount otherAccount = (BankAccount) other;

        return otherAccount.getCode().equals(this.getCode());
    }

    public String getCode(){
        return code;
    }
}
