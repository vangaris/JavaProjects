import java.util.Iterator;
import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {
        //create linked list
        LinkedList<String> list = new LinkedList<String>();

        //adding string - names to list
        list.add("John");
        list.add("Nick");
        list.add("Mary");
        list.add("Helen");

        // Zitaw apo ti domi ena epanalipti (iterator) sinthetos deiktis o opoios deixnei katse fora sto epomeno stoixeio
        // den ton kataskeyazw alla ton lamvanw apo ti domi

        Iterator<String> iterator = list.iterator(); //paragei iterators px has next iterator / kai next

        // sarosi
        while (iterator.hasNext()){
            String name = iterator.next(); // tha parw to prwto stoixeio
            if ((name.equals("Mary"))){
                iterator.remove();
            }


        }

        // 2os tropos kai eykoloteros
        for (String name: list){
            System.out.println("Name: " + name);
        }

        // thelw na diagrapsw to onoma mary, sto for each den mporw na grapsw if



    }
}
