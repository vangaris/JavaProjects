import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class GUI extends JFrame {

    private JTextField nameField;
    private JButton addButton;
    private JList list;
    private JButton sortButton;
    private  JPanel panel;
    //dhmiourgia domis dedomenon lista
    private DefaultListModel model;
    private JScrollPane scrollPane;

    public GUI(){


        nameField = new JTextField(10);
        addButton = new JButton("Add");
        list = new JList();
        sortButton = new JButton("Sort");
        panel = new JPanel();
        //lataskeyh domhs
        model = new DefaultListModel();
        //syndesi medol
        list.setModel(model);
        scrollPane = new JScrollPane(list);

//        xeirismos symvanton exei 4 bhmata:
//        1 dhmiourgia klaseis akroati
//        2 sygrafi toy kodika ekteleshs
//        3   kataskeyh enos antikeimenou akroati
//        4 syndesi toy akroati me thn phgh ton symvanton

       // dhmiourgia symvantos, otan o xristis pliktrologisi to onoma kai patisi add apothikeyetai to model
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                model.addElement(name);


            }
        });

        //taksinomisi sto sort
        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // 1 pernw ta stoixeia apo to model to opoio trofodotei th lista kai ta pernaw se array list
                ArrayList<String> names = Collections.list(model.elements());

                //2 taksinomw ta onomata tou Array list
                Collections.sort(names);

                //3 katharismos medelou pou trofodotei th lista
                model.clear();


                //4 na diatreksoume to array list ta opoia einai pleon taksinominena kai ta pername sto modelo
                for(String name: names)
                    model.addElement(name);





            }
        });





        panel.add(nameField);
        panel.add(addButton);
        panel.add(scrollPane);
        panel.add(sortButton);


        this.setContentPane(panel );


        this.setVisible(true);
        this.setSize(500,500);
    }
}
