import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Main {

    public static void main(String[] args) {

        ArrayList<String> name = new ArrayList<String>();
        name.add("Hellen");

        name.add("Bob");
        name.add("Nick");
        name.add("Mike");
        name.add("Mary");

        System.out.println("----------Sorted---------------");
        Collections.sort(name);

        for(String names: name)
            System.out.println(names);

        System.out.println("----------Shuffled---------------");

        Collections.shuffle(name);

        for(String names: name)
            System.out.println(names);

        System.out.println("----------Reversed---------------");

        Collections.reverse(name);

        for(String names: name)
            System.out.println(names);

        System.out.println("----------Swap---------------");

        Collections.swap(name,2,3);

        for(String names: name)
            System.out.println(names);

        name.add("Hellen");
        name.add("Hellen");
        System.out.println("----------Frequency---------------");
        int freq = Collections.frequency(name,"Hellen");
        System.out.println("Frequency of Hellen is: " + freq);


        System.out.println("----------Max & Min ---------------");
        String max = Collections.max(name);
        String min = Collections.min(name);

        System.out.println("Max: " + max + " /Min: " + min);







    }
}
