import java.util.ArrayList;
import java.util.HashMap;

public class Main {

    public static void main(String[] args) {
        ArrayList<String> johnsBook = new ArrayList<String>();

        johnsBook.add("The catcher in the Rye");
        johnsBook.add("Stven Hawking");

        ArrayList<String> marysBook = new ArrayList<String>();

        marysBook.add("Nefelim");
        marysBook.add("Giati mas psekazoyn?");

        HashMap<String, ArrayList<String>> library = new HashMap<String, ArrayList<String>>();

        library.put("john",johnsBook);
        library.put("Mary", marysBook);

        for(String name : library.keySet()){
            System.out.println(name + " has borrowed: ");
            for (String bookTitle: library.get(name))
                System.out.println(bookTitle);
        }
    }
}
