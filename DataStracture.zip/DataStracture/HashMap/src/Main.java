import java.util.HashMap;
import java.util.HashSet;

public class Main {

    public static void main(String[] args) {

        HashMap<String,String> phoneBook = new HashMap<String, String>();

        //methodos put eisagei zeygaria
        phoneBook.put("Mary", "2310-345778");
        phoneBook.put("John", "2310-552737");
        phoneBook.put("Hellen", "2310-345778");
        phoneBook.put("Nick", "2310-227145");

        System.out.println("Mary's Phone is: " + phoneBook.get("Mary"));

        //gia na diaperasw ola ta stoixeia kalontas th methodo keyset

        for(String name: phoneBook.keySet()){
            System.out.println(name + ": " + phoneBook.get(name));
        }

    }
}
