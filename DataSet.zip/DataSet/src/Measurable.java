public interface Measurable {

    double getMeasure();
}
